<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">  
    function PrintDiv() 
   {  
       var divContents = document.getElementById("print").innerHTML;  
       var printWindow = window.open('', '', 'height=200,width=400');  
       printWindow.document.write(divContents);       
       printWindow.document.close();  
       printWindow.print();  
    }  
</script>  
</head>
<body>
 <input type="button" onclick="PrintDiv();" value="Print" />  
 <div id="print">
<table border="2" cellpadding="20">
<tr>
	<th colspan="7">Invoice</th>
</tr>
<tr>
	<td>Slno</td>
    <td>product</td>
    <td>price</td>
    <td>quantity</td>
    <td>Amount</td>
    <td>tax</td>
    <td>Total amount</td>
</tr>
<?php 
$grand_total=0;
$grand_totaltax=0;
foreach($query as $row)
{
	
 ?>
<tr>
	<td><?php echo $row->id; ?></td>
	<td><?php echo $row->pname; ?></td>
    <td><?php echo $row->price; ?></td>
	<td><?php echo $row->qty; ?></td>
	<td><?php echo $row->amount; ?></td>
	<td><?php echo $row->tax; ?></td>
	<td><?php echo $row->amounttax; ?></td>
	<?php $grand_total=$grand_total+$row->amount; ?>
	<?php $grand_totaltax=$grand_totaltax+$row->amounttax; ?>
</tr>
<?php 

} 
?>
<tr>
    <td colspan="7">Subtotal without tax: $<?php echo $grand_total;?></td>
</tr>
<tr>
    <td colspan="7">Subtotal with tax: $<?php echo $grand_totaltax;?></td>
</tr>
<tr>
<?php
$grand_totaltaxdiscount=$grand_totaltax-(10*$grand_totaltax/100);
?>
    <td colspan="7">Amount after 10% discount $<?php echo $grand_totaltaxdiscount;?></td>
</tr>
</table>
</div>
<BR>

<form method="post" action="<?php echo site_url('Myinsert/index');?>">
        <table> 
            
                <tr> 

                    <td>
                    
                        <input type="text" name="pname" value=""  placeholder="Product Name" />
                        <?php echo form_error('pname'); ?>

                        <input type="text" name="qty" value=""  placeholder="Quantity" />
                        <?php echo form_error('qty'); ?>
                        <input type="text" name="price" value="" placeholder="Unit Price (in $)" />
                        <?php echo form_error('price'); ?>
                        <input type="text" name="tax" value="" placeholder="Tax%" /><br>
                        <?php echo form_error('tax'); ?>
                 
                    </td>
                </tr>
                

            <tr>
                <td colspan="2" align="right">
                     <input type="submit" id="btn" name="add" value="ADD"/>
                </td>
           </tr>
        </table>
        </form>

</body>
</html>