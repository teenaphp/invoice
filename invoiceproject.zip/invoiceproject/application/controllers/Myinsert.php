<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Myinsert extends CI_Controller {

	
	 
	 public function construct()
	{
		parent::construct();
		$this->load->helper('url');
	}
	public function index()
	{		  
		$this->load->model('Insertmodel');
		$data['query']=$this->Insertmodel->view();
		

		$this->load->library('form_validation');
		$this->form_validation->set_rules("pname","name","required");
		$this->form_validation->set_rules("qty","qty gender","required");
		$this->form_validation->set_rules("price","price","required");
		$this->form_validation->set_rules("tax","tax","required");
		
		if($this->form_validation->run())
		{
								
					$this->load->model("Insertmodel");
					$this->Insertmodel->insert();
					redirect("Myinsert/index");
					
				
		}
		$this->load->view('form',$data);

	}
	
	public function p()
	{		  
		$this->load->model('Insertmodel');
		$data['query']=$this->Insertmodel->view();
		$this->load->view('disp',$data);
	}


}
