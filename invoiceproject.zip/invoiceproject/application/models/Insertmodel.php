<?php
class Insertmodel extends CI_Model
{
	function __construct(){
		parent::__construct();
		$this->load->database();
	}
	function insert()
	{
		
		$data=array();
		$data['pname']=$_POST['pname'];
		$data['qty']=$_POST['qty'];
		$data['price']=$_POST['price'];
		$data['tax']=$_POST['tax'];
		$data['amount']=$_POST['qty']*$_POST['price'];
		$data['amounttax']=$data['amount']+($_POST['tax']*$data['amount']/100);
		$this->db->insert('product',$data);
	}


	public function view()
	{
		
		$query=$this->db->get('product');
		return $query->result();
	}
	
}
?>